import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Club, ClubSchema } from './club.schema';
import { ClubService } from './club.service';
import { ClubController } from './club.controller';
import { ClubGateway } from './club.gateway'; // optional realtime
import { AuthModule } from '../auth/auth.module'; // ensure jwt guard available

@Module({
  imports: [MongooseModule.forFeature([{ name: Club.name, schema: ClubSchema }]), AuthModule],
  controllers: [ClubController],
  providers: [ClubService, ClubGateway, { provide: 'SOCKET_SERVER', useFactory: (gw: ClubGateway) => gw.server, inject: [ClubGateway] }],
  exports: [ClubService],
})
export class ClubModule {}
